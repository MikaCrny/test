﻿using Discord;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bot_GUI
{
    public partial class Form1 : Form
    {
        public DiscordSocketClient discordClient;

        IMessageChannel activeChannel;
        SocketRole role;

        List<Color> colours = new List<Color>
        {
            Color.Red,
            Color.Orange,
            Color.Green,
            Color.Blue,
            Color.Magenta,
            Color.Teal,
            Color.Gold
        };
        int colourIndex = 0;

        public Form1()
        {
            InitializeComponent();

            Console.SetOut(new RedirectConsoleOutput(ref tbConsoleOutput));

            MainAsync();
        }

        private void tbConsoleInput_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter && tbConsoleInput.Text.Length > 0)
            {
                HandleCommandInput(tbConsoleInput.Text.Split(' '));
                Console.WriteLine(tbConsoleInput.Text);
                tbConsoleInput.Text = "";
            }
        }

        private async Task MainAsync()
        {
            discordClient = new DiscordSocketClient();
            discordClient.Log += DiscordClient_Log;
            discordClient.Ready += DiscordClient_Ready;

            await discordClient.LoginAsync(TokenType.Bot, "     --------------------  BOT TOKEN  --------------------     ");
            await discordClient.StartAsync();
        }

        private Task DiscordClient_Ready()
        {
            try
            {
                activeChannel = discordClient.GetChannel(676178571982536735) as IMessageChannel; // Default to spam channel
                role = discordClient.GetGuild(570625211976908810).GetRole(570626339812540416);

                Invoke(new Action(() => {
                    tbConsoleInput.Enabled = true;
                    timer1.Enabled = true;
                }));

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return Task.CompletedTask;
            }
        }

        private Task DiscordClient_Log(LogMessage arg)
        {
            Console.WriteLine(arg.Message);
            return Task.CompletedTask;
        }

        private void HandleCommandInput(params string[] values)
        {
            switch (values[0].ToLower())
            {
                case "say":
                    activeChannel.SendMessageAsync(string.Join(" ", values).Remove(0, 4));
                    break;
                case "yell":
                    activeChannel.SendMessageAsync($"@everyone {string.Join(" ", values).Remove(0, 5)}");
                    break;
                case "changechannel":
                    IMessageChannel tempChannel;

                    if ((tempChannel = discordClient.GetChannel(Convert.ToUInt64(values[1])) as IMessageChannel) != null)
                        activeChannel = tempChannel;

                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            role.ModifyAsync(x => x.Color = colours[colourIndex]).Wait();

            colourIndex += 1;
            if (colourIndex == colours.Count)
                colourIndex = 0;
        }
    }
}
